AMAZON DRIVERS
==============

Official repository of the open source drivers for devices used on AWS platforms.

The following drivers are included:


* Linux driver for Elastic Network Adapter (ENA) - Please refer to /kernel/linux/ena
* DPDK driver for ENA (critical fixes for previous DPDK releases) - Please refer to /userspace/dpdk/<DPDK_VERSION>/

For Linux driver SPRM build instruction please refer to
/kernel/linux/rpm/README-rpm.txt
